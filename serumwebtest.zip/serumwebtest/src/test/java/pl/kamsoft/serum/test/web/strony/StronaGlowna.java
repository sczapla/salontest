package pl.kamsoft.serum.test.web.strony;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StronaGlowna extends Strona {
    private WebElement login;
    private WebElement password;
    @FindBy(className = "loginNow")
    private WebElement przyciskZaloguj;

    public StronaGlowna(WebDriver webDriver) {
        super(webDriver);
    }

    public StronaZNalowkiemIMenu zaloguj(String uzytkownik, String haslo) {
        webDriver.manage().window().maximize();
    	login.sendKeys(uzytkownik);
        password.sendKeys(haslo);
        przyciskZaloguj.click();
        return new StronaZNalowkiemIMenu(webDriver);
    }

    public static StronaGlowna otworz(WebDriver webDriver, String bazowyUrl) {
        webDriver.get(bazowyUrl);
        return new StronaGlowna(webDriver);
    }

}

package pl.kamsoft.serum.test.web.strony;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.crm.StronaCRM;
import pl.kamsoft.serum.test.web.strony.pacjenci.StronaPacjenci;
import pl.kamsoft.serum.test.web.strony.zasoby.StronaZasoby;

public class StronaZNalowkiemIMenu extends Strona {
	@FindBy(linkText = "CRM")
	private WebElement menuCRM;
	
    @FindBy(linkText = "Pacjenci")
    private WebElement menuPacjenci;

    @FindBy(linkText = "Zasoby")
    private WebElement menuZasoby;

    @FindBy(linkText = "Wyloguj się")
    private WebElement przyciskWyloguj;

    public StronaZNalowkiemIMenu(WebDriver webDriver) {
        super(webDriver);
    }

    public StronaCRM kliknijMenuCRM() {
    	waitForClickable(menuCRM);
    	menuCRM.click();
    	return new StronaCRM(webDriver);
    }
    
    public StronaPacjenci kliknijMenuPacjenci() {
        waitForClickable(menuPacjenci);
        menuPacjenci.click();
        return new StronaPacjenci(webDriver);
    }

    public StronaZasoby kliknijMenuZasoby() {
        waitForClickable(menuPacjenci);
        menuZasoby.click();
        return new StronaZasoby(webDriver);
    }

    public StronaGlowna kliknijWyloguj() {
        waitForVisible(przyciskWyloguj);
        przyciskWyloguj.click();
        acceptAlertOptionally();
        return new StronaGlowna(webDriver);
    }
}

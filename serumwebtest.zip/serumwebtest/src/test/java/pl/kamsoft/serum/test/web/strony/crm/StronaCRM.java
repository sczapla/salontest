package pl.kamsoft.serum.test.web.strony.crm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.Strona;

public class StronaCRM extends Strona {

	@FindBy(linkText = "MEDYCYNA PRACY") 
	WebElement zakladkaMedycynaPracy;
	
	public StronaCRM(WebDriver webDriver) {
		super(webDriver);
	}
	
	public StronaMedycynaPracy kliknijMedycynaPracy() {
		waitForVisible(zakladkaMedycynaPracy);
		waitForProgressBar();
		zakladkaMedycynaPracy.click();
		return new StronaMedycynaPracy(webDriver);
	}

}

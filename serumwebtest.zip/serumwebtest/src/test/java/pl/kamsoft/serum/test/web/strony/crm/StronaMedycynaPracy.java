package pl.kamsoft.serum.test.web.strony.crm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StronaMedycynaPracy extends StronaCRM {

	@FindBy(linkText = "Dodaj zgłoszenie") 
	WebElement dodajZgloszenie;
	
	public StronaMedycynaPracy(WebDriver webDriver) {
		super(webDriver);
	}
	
	public StronaMedycynaPracyDodanieZgloszenia dodajZgloszenie() {
		waitForProgressBar();
		dodajZgloszenie.click();
		waitForProgressBar();
		return new StronaMedycynaPracyDodanieZgloszenia(webDriver);
	}
}

package pl.kamsoft.serum.test.web.strony.crm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StronaMedycynaPracyDodanieZgloszenia extends StronaMedycynaPracy {

	@FindBy(name = "crm_infolinia_swiad")
	WebElement pacjent;
	
	@FindBy(css = "#crmswiadczenie > div:nth-child(3) > div:nth-child(3) > table > tbody > tr > td:nth-child(3) > a")
	WebElement dodajSkierowanie;

	public StronaMedycynaPracyDodanieZgloszenia(WebDriver webDriver) {
		super(webDriver);
	}
	
//	public StronaMedycynaPracyDodanieZgloszenia wpiszPacjenta(String nazwisko) {
//		pacjent.sendKeys(nazwisko);
//		return this;
//	}
//	
//	public StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania kliknijDodajSkierowanie() {
//		dodajSkierowanie.click();
//		return new StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania(webDriver);
//	}
	
	public StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania dodajSkierowanieDlaPacjenta(String nazwisko) {
		pacjent.sendKeys(nazwisko);
		dodajSkierowanie.click();
		waitForProgressBar();
		dodajSkierowanie.click();
		return new StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania(webDriver);	
	}
}

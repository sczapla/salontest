package pl.kamsoft.serum.test.web.strony.crm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania extends StronaMedycynaPracyDodanieZgloszenia {

	@FindBy(css = "#_uf_przegladarka2 > table > tbody > tr:nth-child(1) > td > div > h3 > div > span")
	WebElement zamknij;
	
	@FindBy(id = "sel_rodzaj_skierownaia_platforma")
	WebElement rodzajSkierowania;
	
	@FindBy(id = "inp_pracodawca_t")
	WebElement pracodawca;
	
	@FindBy(id = "inp_platnik_t")
	WebElement platnik;
	
	@FindBy(id = "inp_stanowiskopracy")
	WebElement stanowiskoPracy;
	
	@FindBy(id = "selRodzajBadania")
	WebElement rodzajBadania;
	
	@FindBy(id = "inp_datawykonaniaodbadania_d")
	WebElement dataOdDzien;
	
	@FindBy(id = "inp_datawykonaniaodbadania_m")
	WebElement dataOdMiesiac;
	
	@FindBy(id = "inp_datawykonaniaodbadania_r")
	WebElement dataOdRok;
	
	@FindBy(id = "inp_datawykonaniaodbadania_g")
	WebElement dataOdGodzina;
	
	@FindBy(id = "inp_datawykonaniaodbadania_mi")
	WebElement dataOdMinuta;
	
	@FindBy(id = "inp_datawykonaniadobadania_d")
	WebElement dataDoDzien;
	
	@FindBy(id = "inp_datawykonaniadobadania_m")
	WebElement dataDoMiesiac;
	
	@FindBy(id = "inp_datawykonaniadobadania_r")
	WebElement dataDoRok;
	
	@FindBy(id = "inp_datawykonaniadobadania_g")
	WebElement dataDoGodzina;
	
	@FindBy(id = "inp_datawykonaniadobadania_mi")
	WebElement dataDoMinuta;
	
	@FindBy(id = "a_zapisz_skierowanie_pacjenta")
	WebElement zapisz;
	
	public StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania(WebDriver webDriver) {
		super(webDriver);
	}
	
	public StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania dodajSkierowanie(String pracodawcaNazwa, 
			String platnikNazwa, String stanowisko, String dzien, String miesiac, String rok, String godzina, 
			String minuta) {
		waitForProgressBar();
        WybierzZListy(rodzajSkierowania, 1);
		pracodawca.sendKeys(pracodawcaNazwa);
        platnik.sendKeys(platnikNazwa);
        stanowiskoPracy.sendKeys(stanowisko);
        WybierzZListy(rodzajBadania, 1);
        dataOdDzien.sendKeys(dzien);
        dataOdMiesiac.sendKeys(miesiac);
        dataOdRok.sendKeys(rok);
        dataOdGodzina.sendKeys(godzina);
        dataOdMinuta.sendKeys(minuta);
        dataDoDzien.sendKeys(dzien);
        dataDoMiesiac.sendKeys(miesiac);
        dataDoRok.sendKeys(rok);
        dataDoGodzina.sendKeys(godzina);
        dataDoMinuta.sendKeys(minuta);        
        zapisz.click();
        waitForProgressBar();
        zamknij.click();
        return new StronaMedycynaPracyDodanieZgloszeniaDodanieSkierowania(webDriver);
    }
	
	private void WybierzZListy(WebElement selectElement, int element) {
		Select select = new Select(selectElement);
    	select.selectByIndex(element);
	}

}

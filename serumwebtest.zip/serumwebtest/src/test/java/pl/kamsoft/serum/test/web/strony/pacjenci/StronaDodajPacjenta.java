package pl.kamsoft.serum.test.web.strony.pacjenci;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.Strona;
import pl.kamsoft.serum.test.web.strony.StronaZNalowkiemIMenu;

public class StronaDodajPacjenta extends Strona {
    @FindBy(linkText = "Zapisz")
    WebElement przyciskZapisz;

    @FindBy(linkText = "Zapisz i wybierz")
    WebElement przyciskZapiszIWybierz;

    @FindBy(id = "pacjent_w_nazwisko")
    WebElement nazwisko;

    @FindBy(id = "pacjent_w_pesel")
    WebElement pesel;

    @FindBy(id = "pacjent_w_imie")
    WebElement imie;

    @FindBy(id = "pacjent_w_adres_miejscowosc")
    WebElement miejscowosc;

    @FindBy(id = "pacjent_w_adres_nrdomu")
    WebElement nrDomu;

    @FindBy(id = "pacjent_w_dataur_d")
    WebElement dataUrDzien;

    @FindBy(id = "pacjent_w_dataur_m")
    WebElement dataUrMiesiac;

    @FindBy(id = "pacjent_w_dataur_r")
    WebElement dataUrRok;

    @FindBy(className = "div_close")
    WebElement krzyzyk;

    public StronaDodajPacjenta(WebDriver webDriver) {
        super(webDriver);
        waitForClickable(nazwisko);
    }

    public StronaDodajPacjenta wpiszNazwisko(String nazwisko) {
        this.nazwisko.sendKeys(nazwisko);
        return this;
    }

    public StronaDodajPacjenta wpiszPesel(String pesel) {
        this.pesel.sendKeys(pesel);
        return this;
    }

    public StronaDodajPacjenta wpiszImie(String imie) {
        this.imie.sendKeys(imie);
        return this;
    }

    public StronaDodajPacjenta wpiszNrDomu(String nrDomu) {
        this.nrDomu.sendKeys(nrDomu);
        return this;
    }

    public StronaDodajPacjenta wpiszDataUrDzien(String dataUrDzien) {
        this.dataUrDzien.sendKeys(dataUrDzien);
        return this;
    }

    public StronaDodajPacjenta wpiszDataUrMiesiac(String dataUrMiesiac) {
        this.dataUrMiesiac.sendKeys(dataUrMiesiac);
        return this;
    }

    public StronaDodajPacjenta wpiszDataUrRok(String dataUrRok) {
        this.dataUrRok.sendKeys(dataUrRok);
        return this;
    }

    public StronaDodajPacjenta wpiszMiejscowosc(String miejscowosc) {
        this.miejscowosc.sendKeys(miejscowosc);
        return this;
    }

    public StronaDodajPacjenta kliknijZapisz() {
        przyciskZapisz.click();
        acceptAlertOptionally();
        return this;
    }

    public StronaPacjenci kliknijZapiszIWybierz() {
        przyciskZapiszIWybierz.click();
        acceptAlertOptionally();
        return new StronaPacjenci(webDriver);
    }

    public StronaZNalowkiemIMenu kliknijZamknij() {
        krzyzyk.click();
        return new StronaZNalowkiemIMenu(webDriver);
    }
}


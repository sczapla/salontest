package pl.kamsoft.serum.test.web.strony.pacjenci;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.StronaZNalowkiemIMenu;

import java.util.List;
import java.util.stream.Collectors;

public class StronaPacjenci extends StronaZNalowkiemIMenu {
    @FindBy(linkText = "Dodaj pacjenta")
    WebElement dodajPacjentaButton;

    @FindBy(id = "wzorzec")
    WebElement wzorzecPacjent;

    @FindBy(linkText = "Filtruj")
    WebElement przyciskFiltruj;

    @FindBy(css = "#contentContainer td.l.b")
    List<WebElement> danePacjenta;

    @FindBy(xpath = "//td[contains(text(),'Wiek')]")
    WebElement elementDanychPacjenta;

    public StronaPacjenci(WebDriver webDriver) {
        super(webDriver);
        waitForClickable(przyciskFiltruj);
    }

    public StronaDodajPacjenta kliknijDodajPacjenta() {
        dodajPacjentaButton.click();
        return new StronaDodajPacjenta(webDriver);
    }

    public StronaPacjenci wpiszWyszukiwanyPacjent(String wyszukiwanyPacjent) {
        wzorzecPacjent.sendKeys(wyszukiwanyPacjent);
        return this;
    }

    public StronaPacjenci kliknijFiltruj() {
        przyciskFiltruj.click();
        waitForClickable(elementDanychPacjenta);
        return new StronaPacjenci(webDriver);
    }

    public String getDanePacjenta() {
        return danePacjenta.stream().map(WebElement::getText).collect(Collectors.joining());


    }
}


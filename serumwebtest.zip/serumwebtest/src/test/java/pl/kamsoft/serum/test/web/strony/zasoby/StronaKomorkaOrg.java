package pl.kamsoft.serum.test.web.strony.zasoby;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.Strona;

public class StronaKomorkaOrg extends Strona {

    @FindBy(id = "jednorgan_kodjednostki_w")
    WebElement poleKodJednostki;

    @FindBy(id = "jednorgan_nazwajednostki_w")
    WebElement poleNazwaJednostki;

    @FindBy(linkText = "Zapisz")
    WebElement przyciskZapisz;

    public StronaKomorkaOrg(WebDriver webDriver) {
        super(webDriver);
        waitForClickable(poleKodJednostki);
    }

    public StronaKomorkaOrg wpiszKodJednostki(String kodJednostki) {
        poleKodJednostki.sendKeys(kodJednostki);
        return this;
    }

    public StronaKomorkaOrg wpiszNazweJednostki(String nazwaJednostki) {
        poleNazwaJednostki.sendKeys(nazwaJednostki);
        return this;
    }

    public StronaZasoby kliknijZapisz() {
        przyciskZapisz.click();
        acceptAlertOptionally();
        waitForProgressBar();
        return new StronaZasoby(webDriver);
    }

}

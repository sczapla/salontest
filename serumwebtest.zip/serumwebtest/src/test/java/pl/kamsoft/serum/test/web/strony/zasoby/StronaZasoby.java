package pl.kamsoft.serum.test.web.strony.zasoby;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pl.kamsoft.serum.test.web.strony.StronaZNalowkiemIMenu;

public class StronaZasoby  extends StronaZNalowkiemIMenu {
    @FindBy(linkText = "Dodaj")
    WebElement przyciskDodaj;

    @FindBy(id = "inp_szukane_kodwlasny")
    WebElement poleKodWlasny;

    @FindBy(id = "inp_szukane_nazwa")
    WebElement poleNazwa;

    @FindBy(linkText = "Filtruj")
    WebElement przyciskFiltruj;

    @FindBy(css = "table.wiersz")
    WebElement daneWTabeli;

    public StronaZasoby(WebDriver webDriver) {
        super(webDriver);
        waitForClickable(poleKodWlasny);
    }

    public StronaKomorkaOrg kliknijDodaj() {
        przyciskDodaj.click();
        return new StronaKomorkaOrg(webDriver);
    }

    public  StronaZasoby wpiszKodWlasny(String kodWlasny) {
        poleKodWlasny.sendKeys(kodWlasny);
        return this;
    }

    public  StronaZasoby wpiszNazwa(String nazwa) {
        poleNazwa.sendKeys(nazwa);
        return this;
    }

    public StronaZasoby kliknijFiltruj() {
        waitForClickable(przyciskFiltruj);
        przyciskFiltruj.click();
        waitForProgressBar();
        return new StronaZasoby(webDriver);
    }

    public String getDaneWTabeli() {
        waitForProgressBar();
        return daneWTabeli.getText();
    }
}

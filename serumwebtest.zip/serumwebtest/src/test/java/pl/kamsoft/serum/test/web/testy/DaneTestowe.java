package pl.kamsoft.serum.test.web.testy;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Klasa umożliwiająca uzyskanie dostępu z testów do danych znajdujących się w plikach properties
 * danetestowe.properties. Uwzględnia przełączony profil tj. pliki danetestowe-PROFIL.properties.
 *
 * Aby dodac obsługę nowego propertiesa wystarczy dodac w tej klasie pole odpowiadajce nazwie propertiesa. Nie musi
 * to być zgodność dokładna np. "bazowyUrl" może być zapisany w pliku propeties jako "bazowy-url" lub "bazowy_url".
 *
 * @author mstalmach
 */
@ConfigurationProperties()
@Getter
@Setter
public class DaneTestowe {
	String uzytkownikMpLogin;
    String uzytkownikMpHaslo;
    String bazowyUrl;

    Integer iloscPacjentow;
    
    String nazwiskoPacjenta;
    String pracodawcaNazwa;
    String platnikNazwa;
    String stanowisko;
    String dzien;
    String miesiac;
    String rok;
    String godzina;
    String minuta;

    Pacjent pacjent1 = new Pacjent();

    String kodJednostki;

    @Getter
    @Setter
    class Pacjent {
		String imie;
        String nazwisko;
    }
}

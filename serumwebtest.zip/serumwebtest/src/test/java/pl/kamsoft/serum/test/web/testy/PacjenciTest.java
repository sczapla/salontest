package pl.kamsoft.serum.test.web.testy;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.*;

import pl.kamsoft.serum.test.web.strony.StronaGlowna;
import pl.kamsoft.serum.test.web.strony.pacjenci.StronaPacjenci;
import pl.kamsoft.serum.test.web.wsparcie.WebTest;

import java.util.Random;

@RunWith(SpringRunner.class)
@WebTest
public class PacjenciTest {

    @Autowired
    WebDriver webDriver;

    @Autowired
    DaneTestowe dane;

    String nazwisko = "Madry" + Long.toString(new Random().nextLong());

    @Test
    public void testDodaniaPacjenta() {
    	StronaGlowna.otworz(webDriver, dane.bazowyUrl)
                .zaloguj(dane.uzytkownikMpLogin, dane.uzytkownikMpHaslo)
                .kliknijMenuPacjenci()
                .kliknijDodajPacjenta()
                .wpiszImie("Filip")
                .wpiszNazwisko(nazwisko)
                .wpiszNrDomu("1")
                .wpiszMiejscowosc("bytom")
                .wpiszDataUrDzien("1")
                .wpiszDataUrMiesiac("1")
                .wpiszDataUrRok("1990")
                .kliknijZapisz()
                .kliknijZamknij();

        StronaPacjenci stronaPacjenci = StronaGlowna.otworz(webDriver, dane.bazowyUrl)
                .zaloguj(dane.uzytkownikMpLogin, dane.uzytkownikMpHaslo)
                .kliknijMenuPacjenci()
                .wpiszWyszukiwanyPacjent(nazwisko)
                .kliknijFiltruj();

        assertThat(stronaPacjenci.getDanePacjenta()).contains(nazwisko);
    }

}

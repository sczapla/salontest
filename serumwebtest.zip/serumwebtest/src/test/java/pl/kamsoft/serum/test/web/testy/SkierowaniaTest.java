package pl.kamsoft.serum.test.web.testy;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.*;

import pl.kamsoft.serum.test.web.strony.StronaGlowna;
import pl.kamsoft.serum.test.web.wsparcie.WebTest;

import java.util.Random;

@RunWith(SpringRunner.class)
@WebTest
public class SkierowaniaTest {

    @Autowired
    WebDriver webDriver;

    @Autowired
    DaneTestowe daneTestowe;

    String nazwisko = "Madry" + Long.toString(new Random().nextLong());

    @Test
//    @Ignore
    public void testDodaniaSkierowania() {
        StronaGlowna.otworz(webDriver, daneTestowe.bazowyUrl)
                .zaloguj(daneTestowe.uzytkownikMpLogin, daneTestowe.uzytkownikMpHaslo)
                .kliknijMenuCRM()
                .kliknijMedycynaPracy()
                .dodajZgloszenie()
                .dodajSkierowanieDlaPacjenta(daneTestowe.nazwiskoPacjenta)
                .dodajSkierowanie(daneTestowe.pracodawcaNazwa, daneTestowe.platnikNazwa, daneTestowe.stanowisko, daneTestowe.dzien, daneTestowe.miesiac, daneTestowe.rok, daneTestowe.godzina, daneTestowe.minuta)
                ;
        assertThat(false);
//        assertThat(stronaPacjenci.getDanePacjenta()).contains(nazwisko);
    }
}

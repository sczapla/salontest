package pl.kamsoft.serum.test.web.testy;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	PacjenciTest.class,
	SkierowaniaTest.class
})


public class WszystkieTest {

}

package pl.kamsoft.serum.test.web.testy;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import pl.kamsoft.serum.test.web.strony.StronaGlowna;
import pl.kamsoft.serum.test.web.strony.zasoby.StronaZasoby;
import pl.kamsoft.serum.test.web.wsparcie.WebTest;

import java.util.Random;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@WebTest
public class ZasobyTest {

    @Autowired
    WebDriver webDriver;

    @Autowired
    DaneTestowe dane;

    @Test
    public void testDodaniaKomorki() {
        String kodJednostki = dane.kodJednostki + Integer.toString(new Random().nextInt());
        String nazwa = "Nazwa" + Long.toString(new Random().nextLong());

        StronaZasoby stronaZasoby = StronaGlowna.otworz(webDriver, dane.bazowyUrl)
                .zaloguj(dane.uzytkownikMpLogin, dane.uzytkownikMpHaslo)
                .kliknijMenuZasoby()
                .kliknijDodaj()
                .wpiszKodJednostki(kodJednostki)
                .wpiszNazweJednostki(nazwa)
                .kliknijZapisz()
                .wpiszNazwa(nazwa)
                .kliknijFiltruj();

        assertThat(stronaZasoby.getDaneWTabeli()).contains(nazwa);
        assertThat(stronaZasoby.getDaneWTabeli()).contains(kodJednostki);
    }
}
